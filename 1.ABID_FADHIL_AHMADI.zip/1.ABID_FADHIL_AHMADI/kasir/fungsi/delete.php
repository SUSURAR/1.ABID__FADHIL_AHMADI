<?php

$koneksi = mysqli_connect('localhost', 'root', '', 'kasir');

// Validasi input
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    
    $delete =  mysqli_query($koneksi, "DELETE FROM transaksi_temp WHERE id='$id'");
    
    // Handle error
    if ($delete) {
        // Redirect ke halaman sebelumnya
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    } else {
        // Tampilkan pesan error jika query gagal
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    // Tampilkan pesan jika id tidak valid
    echo "Invalid ID";
}

?>
