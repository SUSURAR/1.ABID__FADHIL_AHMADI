-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Feb 2024 pada 08.27
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_penjualan`
--

CREATE TABLE `laporan_penjualan` (
  `id` int(11) NOT NULL,
  `kdproduk` text NOT NULL,
  `nm_produk` text NOT NULL,
  `kategori` text NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tanggal` text NOT NULL,
  `jam` text NOT NULL,
  `kasir` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `laporan_penjualan`
--

INSERT INTO `laporan_penjualan` (`id`, `kdproduk`, `nm_produk`, `kategori`, `jumlah_beli`, `total`, `tanggal`, `jam`, `kasir`) VALUES
(45, 'KD0002', 'Ayam Go', '', 1, 25000, '2024-02-06', '10:58 am', 'Admin Kasir ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `nik` int(25) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `jeniskel` char(12) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`id`, `nik`, `Nama`, `jeniskel`, `alamat`, `telp`) VALUES
(13, 52281777, 'Wita mashita', 'Perempuan', ' belanda', '055559'),
(17, 4884, 'jggg', 'Perempuan', ' swxsxs', '088484'),
(18, 0, '', 'Perempuan', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL,
  `NamaPelanggan` varchar(255) NOT NULL,
  `Alamat` text NOT NULL,
  `NomorTelepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `NamaPelanggan`, `Alamat`, `NomorTelepon`) VALUES
(1, 'Dimas', 'Karang waru', '0858147'),
(6, 'Grace gg', 'Bondo', '08585');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_produk`
--

CREATE TABLE `tb_produk` (
  `id` int(11) NOT NULL,
  `kdproduk` text NOT NULL,
  `nm_produk` text NOT NULL,
  `stok` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_produk`
--

INSERT INTO `tb_produk` (`id`, `kdproduk`, `nm_produk`, `stok`, `harga`) VALUES
(13, 'KD0001', 'Mie Instant', 12, 25000),
(15, 'KD0002', 'Ayam Go', 11, 25000),
(17, 'KD0003', 'Kaos', 6, 50000),
(20, 'KD0004', 'Ikan', 55, 25000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_prod_masuk`
--

CREATE TABLE `tb_prod_masuk` (
  `id` int(11) NOT NULL,
  `noinv` text NOT NULL,
  `tanggal` text NOT NULL,
  `jam` text NOT NULL,
  `kdproduk` text NOT NULL,
  `nm_produk` text NOT NULL,
  `kategori` text NOT NULL,
  `rak` text NOT NULL,
  `supplier` text NOT NULL,
  `stok` int(11) NOT NULL,
  `jml_masuk` int(11) NOT NULL,
  `admin` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_prod_masuk`
--

INSERT INTO `tb_prod_masuk` (`id`, `noinv`, `tanggal`, `jam`, `kdproduk`, `nm_produk`, `kategori`, `rak`, `supplier`, `stok`, `jml_masuk`, `admin`) VALUES
(27, 'INV001', '2020-11-18', '07:47 pm', 'KD003', 'Ayam Goreng', 'Makanan', 'RAK 1', 'CV Abadi', 31, 2, 'Admin Kasir Kita'),
(28, 'INV003', '2020-11-22', '05:57 pm', 'KD003', 'Ayam Goreng', 'Makanan', 'RAK 1', 'CV Abadi', 7, 2, 'Admin Kasir ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `nama` text NOT NULL,
  `level` text NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `nama`, `level`, `foto`) VALUES
(11, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin Kasir ', 'admin', '522-admin logoZ.jpg'),
(13, 'kasir', 'c7911af3adbd12a035b289556d96470a', 'kasir', 'kasir', '967-kasir logoZ.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_temp`
--

CREATE TABLE `transaksi_temp` (
  `id` int(11) NOT NULL,
  `kdproduk` text NOT NULL,
  `nm_produk` text NOT NULL,
  `kategori` text NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi_temp`
--

INSERT INTO `transaksi_temp` (`id`, `kdproduk`, `nm_produk`, `kategori`, `jumlah_beli`, `total`) VALUES
(157, 'KD0002', 'Ayam Go', '', 1, 25000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `laporan_penjualan`
--
ALTER TABLE `laporan_penjualan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_prod_masuk`
--
ALTER TABLE `tb_prod_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `transaksi_temp`
--
ALTER TABLE `transaksi_temp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `laporan_penjualan`
--
ALTER TABLE `laporan_penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `tb_prod_masuk`
--
ALTER TABLE `tb_prod_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `transaksi_temp`
--
ALTER TABLE `transaksi_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
