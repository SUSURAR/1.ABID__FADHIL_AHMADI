<?php include 'comp/header.php'; ?>

<?php 
// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST['simpan'])) {
    insert_produk();
  } elseif (isset($_POST['hapus'])) {
    delete_produk();
  } elseif (isset($_POST['edit'])) {
    // Periksa apakah data produk untuk edit sudah dikirimkan
    if (isset($_POST['kdproduk'])) {
      // Panggil fungsi update_produk
      update_produk();
    } else {
      // Tampilkan pesan kesalahan atau kembali ke halaman sebelumnya
      echo "Data produk untuk edit tidak lengkap.";
      // Atau redirect ke halaman sebelumnya
      // header("Location: halaman_sebelumnya.php");
      exit;
    }
  }
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper mt-4">
  <!-- Content Header (Page header) -->
  <!-- /.content-header -->

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-sm-12">
          <div class="well">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
              Tambah data
            </button>
            <!-- Modal -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Tambah produk</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <label>Kode Produk</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" autofocus="" name="kdproduk" aria-describedby="emailHelp">
                      </div>
                      <div class="form-group">
                        <label>Nama Produk</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="nm_produk" aria-describedby="emailHelp">
                      </div>
                      <div class="form-group">
                        <label>Stok</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="stok" aria-describedby="emailHelp">
                      </div>
                      <div class="form-group">
                        <label>Harga</label>
                        <input type="text" class="form-control" name="harga">
                      </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Save changes</button>
                  </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>  
      </div>

      <div class="row">
        <div class="col-sm-12">
          <div class="well">
            <div class="table-responsive table--no-card m-b-30">
              <table class="table table-borderless table-striped table-earning">
                <thead>
                  <tr>
                    <th>NO</th> 
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>     
                  <?php 
                  $i = 1;
                  include 'paging.php';
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div> 
      <!-- /.row -->
    </div>
  </section>
  <!-- /.card-body -->
  <!-- /.card -->
  <!-- solid sales graph -->
</div>

<?php include 'comp/footer.php'; ?>
