<?php include 'comp/header.php'; ?>

<?php 

if (isset($_POST['simpan'])) {
	insert_pelanggan();
}

if (isset($_POST['hapus'])) {
	delete_pelanggan();	
}

if (isset($_POST['edit'])) {
	update_pelanggan();
}

 ?>
<div class="content-wrapper mt-4">
    <!-- Content Header (Page header) -->
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->

        <div class="row">
        	<div class="col-sm-12">
        		<div class="well">
        			<!-- button trigger modal -->
        			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
					  Tambah data
					</button>

					<!-- Modal -->
					<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah pelanggan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST" enctype="multipart/form-data">

  <div class="form-group">
    <label>Nama Pelanggan</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="NamaPelanggan" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label>Alamat</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="Alamat" aria-describedby="emailHelp">
  </div>
   <div class="form-group">
    <label>NomorTelepon</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="NomorTelepon" aria-describedby="emailHelp">
  </div>
    
  

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="simpan" class="btn btn-primary">Save changes</button>
      </div>
        </form>
    </div>
  </div>
</div>
        		</div>
        	</div>	
        </div>

       <div class="row">
        <div class="col-sm-12">
          <div class="well">
             <div class="table-responsive table--no-card m-b-30">
                <table class="table table-borderless table-striped table-earning">
                  <thead>
                    <tr>
                        <th>NO</th> 
                    
                        <th>Nama Pelanggan</th>
                        <th>Alamat</th>
                        <th>Nomor Telepon</th>
                       
                        <th>Aksi</th>
                           
                                                
                    </tr>
                  </thead>
                <tbody>     
                    <?php 
                     $i = 1;
                     include 'paging.php';
                      
                     ?>      
                </tbody>
                    </table>
                                    
                        </div>
          </div>
        </div>

      </div> 
        <!-- /.row -->
        <!-- Main row -->
      
          </section>
              <!-- /.card-body -->
              
            <!-- /.card -->

            <!-- solid sales graph -->
           </div>	

  

<?php include 'comp/footer.php'; ?>