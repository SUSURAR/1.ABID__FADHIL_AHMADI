<?php require 'fungsi/fungsi.php'; ?>

<?php foreach (summon_admin() as $key): ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>halaman admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>  
    <nav class="navbar bg-primary" data-bs-theme="dark"style="background-color: #e3f2fd;">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Halaman Admin</a> 
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div class="offcanvas-header">
       
      </div>
      <div class="offcanvas-body">
        <h3 class="text-center">MENU</h3>
         <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll">
        <li class="nav-item">
         <a href="index.php?m=produk&s=title" class="nav-link">
         <p>Menu Produk</p>
        </a>
         <li class="nav-item">
        <a href="index.php?m=pelanggan&s=title" class="nav-link">
        <p>Menu Pelanggan</p>
         </a> 
         <li class="nav-item">
        <a href="index.php?m=admin&s=title" class="nav-link">
        <p>Menu User</p>
         </a>
       <li class="nav-item">
        <a href="index.php?m=laporan&s=title" class="nav-link">
            <p>Menu Laporan Penjualan</p>
             </a>
         </li>
           <li class="nav-item">
         <a class="btn btn-outline-danger btn-sm" aria-current="page" href="logout.php">Log-out</a>
        </li>
      </div>
    </div>
  </div>
</nav>
    <?php endforeach; ?>
