<?php include 'comp/header.php'; ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                </div><!-- /.col -->
                <div class="col-sm-6">
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- small box -->
                            <div class="inner">
                                <h4>Jumlah User</h4>
                                <h4 style="text-center" ><?= select_user_2(); ?></h4>
                            </div>
                            <div class="icon">
                                <i class="ion ion-ios-people"></i>
                            </div>
                            <a href="index.php?m=admin" class="btn btn-outline-primary small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- small box -->
                            <div class="inner">
                                  <p>Jumlah Produk</p>
                                <h4><?= select_produk(); ?></h4>
                                
                            </div>
                            <div class="icon">
                                <i class="fa fa-archive"></i>
                            </div>
                            <a href="index.php?m=produk&s=title" class="btn btn-outline-primary small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                 <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- small box -->
                            <div class="inner">
                                  <p>Jumlah Pelanggan</p>
                                <h4><?= select_pelanggan(); ?></h4>
                                
                            </div>
                            <div class="icon">
                                <i class="fa fa-archive"></i>
                            </div>
                            <a href="index.php?m=pelanggan&s=title" class="btn btn-outline-primary small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- small box -->
                            <div class="inner">
                              <p>Jumlah Saldo</p>
                                <h4><?= jumlah_saldo(); ?></h4>

                            </div>
                            <a href="index.php?m=laporan" class="btn btn-outline-primary small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- small box -->
                            <div class="inner">
                              <p>Produk Terjual</p>
                                <h4><?= jumlah_terjual(); ?></h4>
                                
                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>
                            <a href="index.php?m=laporan" class="btn btn-outline-primary small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php include 'comp/footer.php'; ?>
