<?php require 'vendors/fungsi/fungsi.php'; ?>

<!DOCTYPE html>
<html>
<title>LOGIN | WEB KASIR</title>
<head>
  <title>kasir1</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <form class="form" action="" method="post">
            <h4 class="text-center mb-4">LOGIN</h4>
            <div class="form-group input-group">
              <span class="input-group-addon"><i class="fa fa-user"></i></span>
              <input class="form-control" type="text" name="user" required="" autofocus="" placeholder="Masukkan username Anda">
            </div>
            <div class="form-group input-group mt-3">
              <span class="input-group-addon"><i class="fa fa-key"></i></span>
              <input class="form-control" type="password" name="pass" value="" required="" placeholder="Password">
            </div>
            <div class="form-group mt-4">
              <a href="index.php" class="btn btn-danger">Batal</a>
              <input class="btn btn-success" type="submit" name="daftar" value="Masuk">
            </div>
            <?php 
              if (@$_POST['daftar']) {
                $proses->login();
              }
            ?>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Promo Section - "We know design" -->

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>

